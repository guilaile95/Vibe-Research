/**
 * R6 本地 walkthrough（不属于提交内容）：隔离真实前后端，走通
 *   路径二：PRE-ENTRY 提交正式决定 → Inbox 可见 → 未交易/未激活；
 *   路径三：/trades UI 人工记账 + 归因/激活尝试（以现有规则为准）；
 *   路径四：独立研究 UI 确认 DISPROVEN 终态 → 旧决定内容不被改写。
 * 关键转移全部通过真实 UI；API 仅用于初始 fixture（已披露）。
 */
import assert from "node:assert/strict";
import { createReadStream, existsSync, mkdirSync, mkdtempSync, readdirSync, rmSync } from "node:fs";
import { createServer } from "node:http";
import { request as httpRequest } from "node:http";
import { spawn, spawnSync } from "node:child_process";
import { tmpdir } from "node:os";
import path, { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { createRequire } from "node:module";
const { chromium } = createRequire(process.env.E2E_REPO_ROOT + "/frontend/package.json")("playwright");

const __dirname = dirname(fileURLToPath(import.meta.url));
const root = process.env.E2E_REPO_ROOT;
const harnessDir = join(root, "frontend/tests/e2e");
const backendDir = path.join(root, "backend");
const frontendDist = path.join(root, "frontend", "dist");
const shotDir = __dirname;
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const findings = [];
const record = (severity, where, message) => {
  findings.push({ severity, where, message });
  console.log(`[r6:${severity}] ${where} — ${message}`);
};

function proxyRequest(url, method, headers, body) {
  return new Promise((resolve, reject) => {
    const target = new URL(url);
    const forwardHeaders = { ...headers, connection: "close" };
    delete forwardHeaders.host;
    const req = httpRequest(
      { hostname: target.hostname, port: target.port, path: `${target.pathname}${target.search}`, method, headers: forwardHeaders },
      (res) => {
        const chunks = [];
        res.on("data", (chunk) => chunks.push(chunk));
        res.on("end", () => resolve({ status: res.statusCode ?? 599, headers: Object.fromEntries(Object.entries(res.headers).filter(([, v]) => v !== undefined).map(([k, v]) => [k, Array.isArray(v) ? v.join(", ") : String(v)])), body: Buffer.concat(chunks) }));
      },
    );
    req.on("error", reject);
    if (body) req.write(body);
    req.end();
  });
}

function freePort() {
  return new Promise((resolve, reject) => {
    const server = createServer();
    server.on("error", reject);
    server.listen(0, "127.0.0.1", () => {
      const address = server.address();
      server.close(() => resolve(address.port));
    });
  });
}

async function waitHttp(url, attempts = 120) {
  for (let i = 0; i < attempts; i += 1) {
    try {
      const response = await fetch(url);
      if (response.ok || response.status < 500) return;
    } catch {}
    await sleep(250);
  }
  throw new Error(`timeout waiting for ${url}`);
}

function startStaticServer(dir, port) {
  const mime = { ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8", ".json": "application/json", ".svg": "image/svg+xml" };
  const server = createServer((request, response) => {
    let pathname = (request.url || "/").split("?")[0];
    if (pathname === "/") pathname = "/index.html";
    let target = path.join(dir, pathname);
    const resolvedDir = path.resolve(dir);
    const resolvedTarget = path.resolve(target);
    if (!resolvedTarget.startsWith(resolvedDir + path.sep) && resolvedTarget !== resolvedDir) {
      response.writeHead(403);
      response.end("forbidden");
      return;
    }
    if (!existsSync(target)) target = path.join(dir, "index.html");
    response.setHeader("Content-Type", mime[path.extname(target)] || "application/octet-stream");
    createReadStream(target).pipe(response);
  });
  return new Promise((resolve, reject) => {
    server.on("error", reject);
    server.listen(port, "127.0.0.1", () => resolve(server));
  });
}

function pythonConfig() {
  if (process.env.PYTHON) return { cmd: process.env.PYTHON, args: ["-m", "uvicorn"] };
  if (process.platform === "win32") return { cmd: "py", args: ["-3", "-m", "uvicorn"] };
  return { cmd: "python3", args: ["-m", "uvicorn"] };
}

function chromiumPath() {
  const bases = [process.env.PLAYWRIGHT_CHROMIUM_PATH, join(process.env.LOCALAPPDATA || "", "ms-playwright"), join(process.env.HOME || "", ".cache", "ms-playwright")];
  for (const base of bases) {
    if (!base || !existsSync(base)) continue;
    if (base.endsWith(".exe") || base.endsWith("chrome") || base.endsWith("Chromium")) return base;
    let entries;
    try { entries = readdirSync(base); } catch { continue; }
    for (const entry of entries) {
      if (!entry.startsWith("chromium-") || entry.includes("headless")) continue;
      const candidates = [join(base, entry, "chrome-win64", "chrome.exe"), join(base, entry, "chrome-linux", "chrome"), join(base, entry, "chrome-mac", "Chromium.app", "Contents", "MacOS", "Chromium")];
      const found = candidates.find((candidate) => existsSync(candidate));
      if (found) return found;
    }
  }
  return undefined;
}

async function jsonRequest(base, pathname, method = "GET", body, expected = 200) {
  const response = await fetch(`${base}${pathname}`, {
    method,
    headers: body === undefined ? undefined : { "content-type": "application/json" },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const payload = await response.json();
  assert.equal(response.status, expected, `${method} ${pathname}: ${JSON.stringify(payload)}`);
  return payload.data;
}

async function screenshot(page, name) {
  mkdirSync(shotDir, { recursive: true });
  await page.screenshot({ path: join(shotDir, name), fullPage: true });
  console.log(`[r6] screenshot ${name}`);
}

async function commitDecisionViaUi(page, campaignId) {
  await page.goto(`${frontend}/campaigns/${campaignId}/decision-proposal`, { waitUntil: "domcontentloaded", timeout: 60000 });
  await page.locator('[data-horizon-source="CURRENT_THESIS"]').waitFor({ timeout: 30000 });
  for (const [index, scenario] of ["Bear", "Base", "Bull"].entries()) {
    const low = [85, 130, 160][index];
    await page.getByLabel(`${scenario} price low`).fill(String(low));
    await page.getByLabel(`${scenario} price high`).fill(String(low + 5));
    await page.getByLabel(`${scenario} assumptions`).fill("合成场景假设");
    await page.getByLabel(`${scenario} input metric`).fill("forward_profit");
    await page.getByLabel(`${scenario} input value`).fill("100");
    await page.getByLabel(`${scenario} input period`).fill("FY2027");
    await page.getByLabel(`${scenario} source`).fill("synthetic-source");
    await page.getByLabel(`${scenario} data at`).fill("2026-08-15");
    await page.getByLabel(`${scenario} horizon`).fill("12 months");
    await page.getByLabel(`${scenario} change conditions`).fill("合成利润变化");
  }
  await page.getByLabel("Candidate entry low").fill("100");
  await page.getByLabel("Candidate entry high").fill("102");
  await page.getByLabel("Candidate invalidation price").fill("90");
  for (const label of ["Data quality", "Evidence confidence", "Inference confidence", "Decision confidence"]) {
    await page.getByLabel(label).selectOption("MEDIUM");
  }
  await page.getByLabel("Review by").fill("2099-01-01T10:00");
  await page.getByLabel("Key assumptions").fill("流动性保持稳定");
  await page.getByLabel("Event invalidation conditions").fill("业绩发生重大反转");
  await page.getByLabel("Asset stance").selectOption("SUPPORT");
  await page.getByLabel("Asset note").fill("高端白酒需求稳定");
  await page.getByLabel("Trade stance").selectOption("SUPPORT");
  await page.getByLabel("Trade note").fill("合成场景：在 100–102 区间小仓位入场");
  await page.getByLabel("Portfolio constraint").fill("单笔风险不超过组合 2%");
  const previewButton = page.getByRole("button", { name: "Preview Proposal" });
  await previewButton.waitFor({ timeout: 30000 });
  await previewButton.click();
  await page.locator('[data-proposal-status="UNCOMMITTED"]').waitFor({ timeout: 180000 });
  await page.locator('[data-challenge-state="ABSENT"]').waitFor();
  for (const label of ["Strongest supporting evidence", "Strongest opposing evidence", "Pre-mortem", "Invalidation facts"]) await page.getByLabel(label, { exact: true }).fill("合成场景：显式核对 " + label);
  await page.getByRole("checkbox", { name: /我已显式填写四个挑战维度/ }).check();
  await page.getByRole("button", { name: "Finalize Decision Challenge" }).click();
  await page.locator("[data-challenge-readback]").waitFor();
  await page.getByRole("checkbox", { name: /Freeze 将绑定这份/ }).check();
  await page.getByRole("checkbox", { name: /我已检查三个独立 View/ }).check();
  await page.getByRole("button", { name: "Freeze Formal Decision" }).click();
  await page.waitForFunction(() => document.querySelector('[data-formal-decision-evaluation]') !== null || document.querySelector('[role="alert"]') !== null, null, { timeout: 180000 });
  const evaluated = await page.locator('[data-formal-decision-evaluation="EVALUATED"]').count();
  assert.equal(evaluated, 1, "commit must read back EVALUATED");
  return (await page.locator("[data-formal-decision-evaluation] p.font-mono").innerText()).replace(/^decision_id：/, "").trim();
}

async function createFrozenCampaignFixture(backend, title) {
  const campaign = await jsonRequest(backend, "/api/campaigns", "POST", { security_code: "600519", strategy: "SWING" }, 201);
  const ev = await jsonRequest(backend, "/api/evidence", "POST", {
    subject_type: "stock", subject_id: "600519", evidence_type: "news",
    claim: `${title} 的支持依据`, source_title: "fixture 纪要", source_url: "https://example.com/fixture",
    source_date: "2026-08-01", accessed_at: "2026-08-01T00:00:00.000Z", classification: "fact", confidence: "high",
  });
  const created = await jsonRequest(backend, "/api/thesis", "POST", {
    subject_type: "stock", subject_id: "600519", title, summary: "fixture", core_claims: ["claim one", "claim two", "claim three"],
    catalysts: [], risks: [], invalidation_conditions: [], change_summary: "fixture",
  }, 200);
  const thesisId = created.thesis.id;
  const currentRevision = async () => (await jsonRequest(backend, `/api/thesis/${thesisId}`)).thesis.current_revision;
  await jsonRequest(backend, `/api/thesis/${thesisId}/evidence`, "POST", { evidence_id: ev.id, stance: "support", expected_revision: await currentRevision() });
  const begun = await jsonRequest(backend, `/api/thesis/${thesisId}/begin-formalization`, "POST", {}, 200);
  const updated = await jsonRequest(backend, `/api/thesis/${thesisId}`, "PUT", {
    title: begun.thesis.title, summary: begun.thesis.summary, status: "active",
    core_claims: begun.thesis.core_claims, catalysts: [], risks: [],
    invalidation_conditions: ["业绩发生重大反转"], strategy: "SWING",
    expected_horizon: { unit: "TRADING_DAY", min: 10, max: 30, anchor: "FREEZE_AT" },
    free_notes: null, expected_revision: begun.thesis.current_revision, change_summary: "fixture",
  }, 200);
  const confirmed = await jsonRequest(backend, `/api/thesis/${thesisId}/confirm`, "POST", { expected_revision: updated.thesis.current_revision }, 200);
  await jsonRequest(backend, `/api/thesis/${thesisId}/freeze`, "POST", { expected_revision: confirmed.thesis.current_revision }, 200);
  await jsonRequest(backend, `/api/campaigns/${campaign.campaign_id}/thesis-binding`, "POST", { thesis_id: thesisId }, 201);
  for (const [from, to] of [["DRAFT", "RESEARCHING"], ["RESEARCHING", "PRE-ENTRY"]]) {
    await jsonRequest(backend, `/api/campaigns/${campaign.campaign_id}/transitions`, "POST", { expected_status: from, to_status: to }, 200);
  }
  return { campaign, thesisId, evidenceId: ev.id };
}

let frontend = "";
async function run() {
  assert.ok(existsSync(frontendDist), "frontend/dist must be built");
  const tempDataDir = mkdtempSync(join(tmpdir(), "vr-r6-paths-"));
  let backendProc;
  let backendLog = "";
  let staticServer;
  let browser;
  try {
    const backendPort = await freePort();
    const frontendPort = await freePort();
    const backend = `http://127.0.0.1:${backendPort}`;
    frontend = `http://127.0.0.1:${frontendPort}`;
    const py = pythonConfig();
    const env = {
      ...process.env,
      VR_DATA_DIR: tempDataDir,
      VR_REPORTS_DIR: tempDataDir,
      VIBE_RESEARCH_TRADE_LEDGER_DB: join(tempDataDir, "trade_ledger.sqlite3"),
      VIBE_RESEARCH_REVIEW_DB: join(tempDataDir, "review_history.db"),
      VIBE_RESEARCH_EVIDENCE_THESIS_DB: join(tempDataDir, "evidence_thesis.db"),
      VIBE_RESEARCH_CAMPAIGN_DB: join(tempDataDir, "campaigns.sqlite3"),
      VIBE_RESEARCH_FROZEN_DECISION_DB: join(tempDataDir, "frozen_decisions.sqlite3"),
      PYTHONUNBUFFERED: "1",
      VR_ALLOW_ORIGINS: frontend,
      PYTHONPATH: [__dirname, harnessDir, backendDir, process.env.PYTHONPATH].filter(Boolean).join(path.delimiter),
    };
    backendProc = spawn(py.cmd, [...py.args, "goal_v2_harness:app", "--host", "127.0.0.1", "--port", String(backendPort)], { cwd: backendDir, env, stdio: ["ignore", "pipe", "pipe"] });
    backendProc.stdout.on("data", (c) => { backendLog += c.toString(); });
    backendProc.stderr.on("data", (c) => { backendLog += c.toString(); });
    await waitHttp(`${backend}/api/health`);
    await jsonRequest(backend, "/api/position/bootstrap-commit", "POST", {
      ledger_start_at: "2026-08-01",
      opening_cash: 1000000,
      positions: [],
    }, 200);
    await jsonRequest(backend, "/api/account-profile", "PUT", { total_assets: 1000000, available_cash: 1000000, confirm_current: true });
    staticServer = await startStaticServer(frontendDist, frontendPort);
    const launchOptions = { headless: true };
    const executablePath = chromiumPath();
    if (executablePath) launchOptions.executablePath = executablePath;
    try {
      browser = await chromium.launch(launchOptions);
    } catch {
      browser = await chromium.launch({ headless: true, channel: "chrome" });
    }
    const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
    const appErrors = [];
    page.on("pageerror", (error) => appErrors.push(error.message));
    page.on("console", (message) => { if (message.type() === "error") console.log("[browser console] " + message.text()); });
    await page.route("https://fonts.googleapis.com/**", (route) => route.fulfill({ contentType: "text/css", body: "" }));
    await page.route("**/api/**", async (route) => {
      const request = route.request();
      const url = new URL(request.url());
      try {
        const response = await proxyRequest(`${backend}${url.pathname}${url.search}`, request.method(), request.headers(), ["GET", "HEAD"].includes(request.method()) ? undefined : request.postDataBuffer());
        await route.fulfill({ status: response.status, headers: response.headers, body: response.body });
      } catch (error) {
        await route.fulfill({ status: 599, contentType: "application/json", body: JSON.stringify({ detail: "proxy failed" }) });
      }
    });

    // ============ 路径二：PRE-ENTRY 决定可见但未交易 ============
    const campaignA = await createFrozenCampaignFixture(backend, "Path2 Formal Thesis");
    record("INFO", "fixture", `Campaign A=${campaignA.campaign.campaign_id}（PRE-ENTRY，fixture 准备）`);
    const decisionA = await commitDecisionViaUi(page, campaignA.campaign.campaign_id);
    record("INFO", "路径三准备", `PRE-ENTRY 经 UI 提交正式决定 ${decisionA}`);

    const committedBefore = await jsonRequest(backend, `/api/campaigns/${campaignA.campaign.campaign_id}/decision-proposal/committed/${decisionA}`);
    assert.equal(committedBefore.committed.next_best_action, "BUY SMALL");
    assert.equal((await jsonRequest(backend, `/api/campaigns/${campaignA.campaign.campaign_id}`)).status, "PRE-ENTRY");
    // ============ 路径三：人工记账 + 归因/激活尝试（真实 UI） ============
    await page.goto(`${frontend}/trades`, { waitUntil: "domcontentloaded", timeout: 60000 });
    await page.getByRole("button", { name: "新建交易" }).first().waitFor({ timeout: 30000 });
    await page.getByRole("button", { name: "新建交易" }).first().click();
    await page.getByLabel("股票代码").fill("600519");
    await page.getByLabel("股票名称").fill("贵州茅台");
    await page.locator("select").filter({ hasText: "请选择操作类型" }).first().selectOption("buy");
    await page.locator("select").filter({ hasText: "请选择执行状态" }).first().selectOption("full");
    await page.locator('input[placeholder="大于0"]').first().fill("100");
    await page.locator('input[placeholder="正整数"]').first().fill("100");
    await page.getByLabel("实际成交时间").fill(await page.evaluate(() => {
      const d = new Date(Date.now() + 60000), pad = (n) => String(n).padStart(2, "0");
      return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
    }));
    // 手续费与其他费用都是必填（0 表示确认费用为 0）。
    const feeInputs = page.locator('input[placeholder*="实际费用"]');
    const feeCount = await feeInputs.count();
    for (let index = 0; index < feeCount; index += 1) await feeInputs.nth(index).fill("0");
    const createdResponse = page.waitForResponse((response) => new URL(response.url()).pathname === "/api/trades" && response.request().method() === "POST");
    await page.locator('button:has-text("提交创建")').click();
    const createdPayload = await (await createdResponse).json();
    const trade = createdPayload.data;
    assert.ok(trade.trade_id, JSON.stringify(createdPayload));
    await page.getByRole("button", { name: "关闭", exact: true }).click();
    await page.getByRole("button", { name: "详情", exact: true }).first().click();
    await page.getByText("交易归属与 Campaign 对账").waitFor();
    await page.locator("[data-continuation-candidate]").filter({ hasText: decisionA }).getByRole("button", { name: "明确归属" }).click();
    await page.getByText("ALLOCATED", { exact: true }).waitFor();
    const attributionBefore = await jsonRequest(backend, `/api/trades/${trade.trade_id}/reconciliation`);
    assert.equal(attributionBefore.decision_id, decisionA);
    assert.equal(attributionBefore.campaign_id, campaignA.campaign.campaign_id);
    assert.equal((await jsonRequest(backend, `/api/campaigns/${campaignA.campaign.campaign_id}`)).status, "PRE-ENTRY");
    await screenshot(page, "path3-attributed-not-activated.png");
    await page.getByTestId("activate-campaign-from-trade").click();
    await page.getByText("Campaign 已激活", { exact: true }).waitFor();
    assert.equal((await jsonRequest(backend, `/api/campaigns/${campaignA.campaign.campaign_id}`)).status, "ACTIVE");
    await screenshot(page, "path3-explicitly-activated.png");
    console.log("[R6 path3 PASS] UI commit BUY SMALL + Challenge -> trade creation -> detail -> explicit attribution -> explicit activation; " + JSON.stringify({ decision_id: decisionA, trade_id: trade.trade_id, attribution: attributionBefore }));
    // ============ 路径四：后来证伪，仍能回看当时决定 ============
    const campaignC = campaignA;
    const decisionC = decisionA;
    const originalBefore = await jsonRequest(backend, `/api/campaigns/${campaignC.campaign.campaign_id}/current-thesis`);
    const beforeDelta = await jsonRequest(backend, `/api/campaigns/${campaignC.campaign.campaign_id}/decision-proposal/committed/${decisionC}`);
    // UI：在 Thesis C 页新建证据并确认 DISPROVEN（关键转移走真实 UI）
    await page.goto(`${frontend}/evidence/new?subject_type=stock&subject_id=600519&return_to=${encodeURIComponent(`/thesis/${campaignC.thesisId}`)}`, { waitUntil: "domcontentloaded" });
    await page.locator("select").first().waitFor();
    await page.locator("select").nth(1).selectOption("news");
    await page.fill('input[placeholder*="600519"]', "600519");
    await page.fill('textarea[placeholder*="一句话"]', "后来证伪：渠道数据显示核心假设不成立");
    await page.fill('input[placeholder*="XX公司"]', "终态复核纪要");
    await page.fill('input[type="date"]', "2026-08-27");
    await page.locator("label:has-text('分类') select").selectOption("fact");
    await page.locator("label:has-text('置信度') select").selectOption("high");
    await page.fill('input[type="datetime-local"]', "2026-08-27T18:00");
    await page.locator('button:has-text("保存")').click();
    await page.waitForURL(new RegExp(`/thesis/${campaignC.thesisId}$`));
    const deltaPanel = page.getByTestId("thesis-delta-confirm");
    await sleep(2500);
    const debugBody = (await page.locator("body").innerText()).slice(0, 600);
    await deltaPanel.waitFor();
    const newOption = page.locator("select[aria-label='选择证据'] option", { hasText: "后来证伪：渠道数据显示核心假设不成立" }).last();
    const optionValue = await newOption.getAttribute("value");
    assert.ok(optionValue, "new evidence must be selectable");
    await page.getByLabel("选择证据").selectOption(optionValue);
    await page.getByTestId("delta-evidence-summary").waitFor();
    await page.getByLabel("本次变更立场").selectOption("oppose");
    await page.getByLabel("研究变化状态").selectOption("DISPROVEN");
    await page.getByLabel("变更原因").fill("渠道数据证伪核心假设");
    await page.getByTestId("delta-preview").waitFor();
    await page.getByLabel("我已核对证据内容与本次立场，确认追加这条研究变化").check();
    await page.getByTestId("confirm-thesis-delta").click();
    await page.getByTestId("delta-readback").getByText("#1 · DISPROVEN").waitFor({ timeout: 30000 });
    record("INFO", "路径四", "UI 确认 DISPROVEN 终态变更成功（readback #1）");
    // 终态横幅 + 旧决定不被改写
    await page.goto(`${frontend}/campaigns/${campaignC.campaign.campaign_id}/decision-proposal`, { waitUntil: "domcontentloaded" });
    await page.locator('[data-horizon-source="CURRENT_THESIS"]').waitFor({ timeout: 30000 });
    await page.getByTestId("research-brief-terminal-state").waitFor({ timeout: 30000 });
    const terminalText = await page.getByTestId("research-brief-terminal-state").innerText();
    assert.match(terminalText, /已证伪/);
    await screenshot(page, "path4-terminal-banner.png");
    const originalAfter = await jsonRequest(backend, `/api/campaigns/${campaignC.campaign.campaign_id}/current-thesis`);
    assert.deepEqual(originalAfter.original_snapshot, originalBefore.original_snapshot);
    const afterDelta = await jsonRequest(backend, `/api/campaigns/${campaignC.campaign.campaign_id}/decision-proposal/committed/${decisionC}`);
    assert.deepEqual(afterDelta.committed, beforeDelta.committed, "old decision content must be untouched");
    const attributionAfter = await jsonRequest(backend, `/api/trades/${trade.trade_id}/reconciliation`);
    const { as_of: beforeReadAt, ...beforeAttribution } = attributionBefore;
    const { as_of: afterReadAt, ...afterAttribution } = attributionAfter;
    assert.deepEqual(afterAttribution, beforeAttribution, "terminal update must not rewrite existing attribution (read timestamp excluded)");
    console.log("[R6 path4 PASS] terminal DISPROVEN; committed snapshot and existing attribution unchanged");
    record("INFO", "路径四", `旧决定 ${decisionC} 内容逐字段未变（committed 相等）；终态横幅=已证伪`);
    // 终态后禁止继续追加（后端既有约束在 UI 路径上也成立）
    const secondDelta = await fetch(`${backend}/api/thesis/${campaignC.thesisId}/deltas`, {
      method: "POST", headers: { "content-type": "application/json" },
      body: JSON.stringify({ delta_state: "STABLE", reason: "终态后再试一条", evidence_ids: [] }),
    });
    assert.notEqual(secondDelta.status, 200, "terminal delta must reject further appends");
    record("INFO", "路径四", "终态后追加被拒绝（HTTP " + secondDelta.status + "）——既有边界保持");

    console.log("\n===== R6 FINDINGS =====");
    for (const f of findings) console.log(`${f.severity} | ${f.where} | ${f.message}`);
    assert.deepEqual(appErrors, [], "no browser runtime exceptions");
    assert.equal(await page.locator("vite-error-overlay").count(), 0);
    console.log("[browser identity] " + JSON.stringify({ url: page.url(), title: await page.title(), viewport: page.viewportSize() }));
  } catch (error) {
    if (backendProc && !backendProc.killed) console.error(backendLog || "backend log unavailable");
    throw error;
  } finally {
    if (browser) await browser.close();
    if (staticServer) await new Promise((resolve) => staticServer.close(resolve));
    if (backendProc && !backendProc.killed) {
      if (process.platform === "win32") {
        spawnSync("taskkill", ["/PID", String(backendProc.pid), "/T", "/F"], { stdio: "ignore", windowsHide: true });
      } else {
        backendProc.kill();
      }
      await new Promise((resolve) => backendProc.once("close", resolve));
    }
    try { rmSync(tempDataDir, { recursive: true, force: true }); } catch (cleanupError) {
      console.error(`[r6] temp dir cleanup skipped: ${cleanupError.code ?? cleanupError}`);
    }
  }
}


run().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
