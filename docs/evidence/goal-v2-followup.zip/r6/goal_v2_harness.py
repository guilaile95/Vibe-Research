"""Synthetic source inputs only; production decision, trade and lifecycle writers remain intact."""
import os
from pathlib import Path
assert Path(os.environ["VR_DATA_DIR"]).name.startswith("vr-r6-paths-")
import campaign_critical_data_runtime as ccd
# Fixed normalized capability observations are initial synthetic market data.
# Dependency resolution and the real CCD projector still decide usability.
def synthetic_capabilities(definition, **_kwargs):
    return [{"dependency_id": key, "state": "USABLE", "as_of": definition["as_of"],
             "authority_refs": ["synthetic-r6-source:" + key]}
            for key in definition["required_dependency_ids"]]
ccd._capability_results = synthetic_capabilities
from decision_challenge_backend_harness import app
