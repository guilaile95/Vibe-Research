import csv, json, subprocess, sys
from datetime import date, timedelta
from pathlib import Path
import research_data_plane as rdp
out=Path(__file__).resolve().parent
dates=[(date(2024,1,1)+timedelta(days=i)).isoformat() for i in range(130)]
series={'600001':(dates[:86],[100.0]*80+[101.0]*5+[80.8]),'600003':(dates[1:87],[100.0]*80+[101.0]*5+[92.92]),'600002':(dates[:86],[100.0]*85+[87.0]),'600004':(dates,[100.0]*130)}
source=out/'synthetic-source.csv'
with source.open('w',encoding='utf-8',newline='') as f:
    writer=csv.writer(f);writer.writerow(['code','trade_date','open','high','low','close','volume'])
    for code,(ds,closes) in series.items():
        writer.writerows([code,d,c,c,c,c,1000] for d,c in zip(ds,closes))
rdp.import_csv(source,root=out/'rdp')
command=[sys.executable,'-m','research_prototypes.signal_effect_study','--data-root',str(out/'rdp'),'--codes','600001,600003','--benchmark-code','600002','--date-from',dates[0],'--date-to',dates[99],'--out-prefix',str(out/'study')]
result=subprocess.run(command,capture_output=True,text=True,check=True)
report=json.loads((out/'study.json').read_text(encoding='utf-8'))
with (out/'study.csv').open(encoding='utf-8',newline='') as f: rows=list(csv.DictReader(f))
d=report['data']; bucket=report['results']['5']
assert d['requested_date_from']==dates[0] and d['requested_date_to']==dates[99]
assert d['coverage_end']==dates[-1]
assert d['actual_sample_ranges']=={'600001':{'date_from':dates[0],'date_to':dates[85],'observations':86},'600003':{'date_from':dates[1],'date_to':dates[86],'observations':86}}
assert d['actual_benchmark_range']=={'date_from':dates[0],'date_to':dates[85],'observations':86}
assert bucket['worst_observation']['code']=='600001' and bucket['worst_observation_basis']=='return_pct'
assert bucket['worst_observation_eligible_count']==2 and bucket['excess_return']['count']==1
assert [(r['code'],r['status'],r['is_worst'],r['is_failure']) for r in rows if r['window']=='5']==[('600001','EVALUATED','yes','yes'),('600003','EVALUATED','','')]
for window,b in report['results'].items():
    rs=[r for r in rows if r['window']==window]
    assert len(rs)==b['events_total']+b['events_excluded_unknown_prior']
    assert sum(r['is_failure']=='yes' for r in rs)==(b['failures'] or 0)
assert report['schema_version']=='signal_effect_study.v0.3' and report['historical_validity']['status']=='NOT_PROVEN'
(out/'cli-readback.txt').write_text('COMMAND: '+subprocess.list2cmdline(command)+'\n'+result.stdout+'PASS: source import -> real CLI -> JSON/CSV readback; consistent worst basis; missing benchmark retained; counts/flags reconciled; requested, actual and dataset coverage distinct; HISTORICAL_VALIDITY=NOT_PROVEN\n',encoding='utf-8')
print((out/'cli-readback.txt').read_text(encoding='utf-8'))

