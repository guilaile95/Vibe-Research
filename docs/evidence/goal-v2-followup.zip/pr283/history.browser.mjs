/**
 * R6 本地 walkthrough（不属于提交内容）：隔离真实前后端，走通
 *   路径二：PRE-ENTRY 提交正式决定 → Inbox 可见 → 未交易/未激活；
 *   路径三：/trades UI 人工记账 + 归因/激活尝试（以现有规则为准）；
 *   路径四：独立研究 UI 确认 DISPROVEN 终态 → 旧决定内容不被改写。
 * 关键转移全部通过真实 UI；API 仅用于初始 fixture（已披露）。
 */
import assert from "node:assert/strict";
import { createReadStream, existsSync, mkdirSync, mkdtempSync, readdirSync, rmSync } from "node:fs";
import { createServer } from "node:http";
import { request as httpRequest } from "node:http";
import { spawn, spawnSync } from "node:child_process";
import { tmpdir } from "node:os";
import path, { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { createRequire } from "node:module";
const { chromium } = createRequire(process.env.E2E_REPO_ROOT + "/frontend/package.json")("playwright");

const __dirname = dirname(fileURLToPath(import.meta.url));
const root = process.env.E2E_REPO_ROOT;
const harnessDir = join(root, "frontend/tests/e2e");
const backendDir = path.join(root, "backend");
const frontendDist = path.join(root, "frontend", "dist");
const shotDir = process.env.E2E_SCREENSHOT_DIR;
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const findings = [];
const record = (severity, where, message) => {
  findings.push({ severity, where, message });
  console.log(`[r6:${severity}] ${where} — ${message}`);
};

function proxyRequest(url, method, headers, body) {
  return new Promise((resolve, reject) => {
    const target = new URL(url);
    const forwardHeaders = { ...headers, connection: "close" };
    delete forwardHeaders.host;
    const req = httpRequest(
      { hostname: target.hostname, port: target.port, path: `${target.pathname}${target.search}`, method, headers: forwardHeaders },
      (res) => {
        const chunks = [];
        res.on("data", (chunk) => chunks.push(chunk));
        res.on("end", () => resolve({ status: res.statusCode ?? 599, headers: Object.fromEntries(Object.entries(res.headers).filter(([, v]) => v !== undefined).map(([k, v]) => [k, Array.isArray(v) ? v.join(", ") : String(v)])), body: Buffer.concat(chunks) }));
      },
    );
    req.on("error", reject);
    if (body) req.write(body);
    req.end();
  });
}

function freePort() {
  return new Promise((resolve, reject) => {
    const server = createServer();
    server.on("error", reject);
    server.listen(0, "127.0.0.1", () => {
      const address = server.address();
      server.close(() => resolve(address.port));
    });
  });
}

async function waitHttp(url, attempts = 120) {
  for (let i = 0; i < attempts; i += 1) {
    try {
      const response = await fetch(url);
      if (response.ok || response.status < 500) return;
    } catch {}
    await sleep(250);
  }
  throw new Error(`timeout waiting for ${url}`);
}

function startStaticServer(dir, port) {
  const mime = { ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8", ".json": "application/json", ".svg": "image/svg+xml" };
  const server = createServer((request, response) => {
    let pathname = (request.url || "/").split("?")[0];
    if (pathname === "/") pathname = "/index.html";
    let target = path.join(dir, pathname);
    const resolvedDir = path.resolve(dir);
    const resolvedTarget = path.resolve(target);
    if (!resolvedTarget.startsWith(resolvedDir + path.sep) && resolvedTarget !== resolvedDir) {
      response.writeHead(403);
      response.end("forbidden");
      return;
    }
    if (!existsSync(target)) target = path.join(dir, "index.html");
    response.setHeader("Content-Type", mime[path.extname(target)] || "application/octet-stream");
    createReadStream(target).pipe(response);
  });
  return new Promise((resolve, reject) => {
    server.on("error", reject);
    server.listen(port, "127.0.0.1", () => resolve(server));
  });
}

function pythonConfig() {
  if (process.env.PYTHON) return { cmd: process.env.PYTHON, args: ["-m", "uvicorn"] };
  if (process.platform === "win32") return { cmd: "py", args: ["-3", "-m", "uvicorn"] };
  return { cmd: "python3", args: ["-m", "uvicorn"] };
}

function chromiumPath() {
  const bases = [process.env.PLAYWRIGHT_CHROMIUM_PATH, join(process.env.LOCALAPPDATA || "", "ms-playwright"), join(process.env.HOME || "", ".cache", "ms-playwright")];
  for (const base of bases) {
    if (!base || !existsSync(base)) continue;
    if (base.endsWith(".exe") || base.endsWith("chrome") || base.endsWith("Chromium")) return base;
    let entries;
    try { entries = readdirSync(base); } catch { continue; }
    for (const entry of entries) {
      if (!entry.startsWith("chromium-") || entry.includes("headless")) continue;
      const candidates = [join(base, entry, "chrome-win64", "chrome.exe"), join(base, entry, "chrome-linux", "chrome"), join(base, entry, "chrome-mac", "Chromium.app", "Contents", "MacOS", "Chromium")];
      const found = candidates.find((candidate) => existsSync(candidate));
      if (found) return found;
    }
  }
  return undefined;
}

async function jsonRequest(base, pathname, method = "GET", body, expected = 200) {
  const response = await fetch(`${base}${pathname}`, {
    method,
    headers: body === undefined ? undefined : { "content-type": "application/json" },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const payload = await response.json();
  assert.equal(response.status, expected, `${method} ${pathname}: ${JSON.stringify(payload)}`);
  return payload.data;
}

async function screenshot(page, name) {
  mkdirSync(shotDir, { recursive: true });
  await page.screenshot({ path: join(shotDir, name), fullPage: true });
  console.log(`[r6] screenshot ${name}`);
}

async function commitDecisionViaUi(page, campaignId, note = "第一份历史判断") {
  await page.goto(`${frontend}/campaigns/${campaignId}/decision-proposal`, { waitUntil: "domcontentloaded", timeout: 60000 });
  await page.locator('[data-horizon-source="CURRENT_THESIS"]').waitFor({ timeout: 30000 });
  await page.getByLabel("Candidate valuation anchors unavailable").check();
  for (const label of ["Data quality", "Evidence confidence", "Inference confidence", "Decision confidence"]) {
    await page.getByLabel(label).selectOption({ index: 1 });
  }
  await page.getByLabel("Review by").fill("2099-01-01T10:00");
  await page.getByLabel("Key assumptions").fill(note);
  await page.getByLabel("Event invalidation conditions").fill("业绩发生重大反转");
  await page.getByLabel("Asset stance").selectOption("SUPPORT");
  await page.getByLabel("Asset note").fill("高端白酒需求稳定");
  await page.getByLabel("Trade stance").selectOption("WAIT");
  await page.getByLabel("Trade note").fill("等待缩量回调再入场");
  await page.getByLabel("Portfolio constraint").fill("单笔风险不超过组合 2%");
  const previewButton = page.getByRole("button", { name: "Preview Proposal" });
  await previewButton.waitFor({ timeout: 30000 });
  await previewButton.click();
  await page.locator('[data-proposal-status="UNCOMMITTED"]').waitFor({ timeout: 180000 });
  await page.getByRole("checkbox", { name: /我已检查三个独立 View/ }).check();
  await page.getByRole("button", { name: "Freeze Formal Decision" }).click();
  await page.waitForFunction(() => document.querySelector('[data-formal-decision-evaluation]') !== null || document.querySelector('[role="alert"]') !== null, null, { timeout: 180000 });
  const evaluated = await page.locator('[data-formal-decision-evaluation="EVALUATED"]').count();
  assert.equal(evaluated, 1, "commit must read back EVALUATED");
  return (await page.locator("[data-formal-decision-evaluation] p.font-mono").innerText()).replace(/^decision_id：/, "").trim();
}

async function createFrozenCampaignFixture(backend, title) {
  const campaign = await jsonRequest(backend, "/api/campaigns", "POST", { security_code: "600519", strategy: "SWING" }, 201);
  const ev = await jsonRequest(backend, "/api/evidence", "POST", {
    subject_type: "stock", subject_id: "600519", evidence_type: "news",
    claim: `${title} 的支持依据`, source_title: "fixture 纪要", source_url: "https://example.com/fixture",
    source_date: "2026-08-01", accessed_at: "2026-08-01T00:00:00.000Z", classification: "fact", confidence: "high",
  });
  const created = await jsonRequest(backend, "/api/thesis", "POST", {
    subject_type: "stock", subject_id: "600519", title, summary: "fixture", core_claims: ["claim one", "claim two", "claim three"],
    catalysts: [], risks: [], invalidation_conditions: [], change_summary: "fixture",
  }, 200);
  const thesisId = created.thesis.id;
  const currentRevision = async () => (await jsonRequest(backend, `/api/thesis/${thesisId}`)).thesis.current_revision;
  await jsonRequest(backend, `/api/thesis/${thesisId}/evidence`, "POST", { evidence_id: ev.id, stance: "support", expected_revision: await currentRevision() });
  const begun = await jsonRequest(backend, `/api/thesis/${thesisId}/begin-formalization`, "POST", {}, 200);
  const updated = await jsonRequest(backend, `/api/thesis/${thesisId}`, "PUT", {
    title: begun.thesis.title, summary: begun.thesis.summary, status: "active",
    core_claims: begun.thesis.core_claims, catalysts: [], risks: [],
    invalidation_conditions: ["业绩发生重大反转"], strategy: "SWING",
    expected_horizon: { unit: "TRADING_DAY", min: 10, max: 30, anchor: "FREEZE_AT" },
    free_notes: null, expected_revision: begun.thesis.current_revision, change_summary: "fixture",
  }, 200);
  const confirmed = await jsonRequest(backend, `/api/thesis/${thesisId}/confirm`, "POST", { expected_revision: updated.thesis.current_revision }, 200);
  await jsonRequest(backend, `/api/thesis/${thesisId}/freeze`, "POST", { expected_revision: confirmed.thesis.current_revision }, 200);
  await jsonRequest(backend, `/api/campaigns/${campaign.campaign_id}/thesis-binding`, "POST", { thesis_id: thesisId }, 201);
  for (const [from, to] of [["DRAFT", "RESEARCHING"], ["RESEARCHING", "PRE-ENTRY"]]) {
    await jsonRequest(backend, `/api/campaigns/${campaign.campaign_id}/transitions`, "POST", { expected_status: from, to_status: to }, 200);
  }
  return { campaign, thesisId, evidenceId: ev.id };
}

let frontend = "";
async function run() {
  assert.ok(existsSync(frontendDist), "frontend/dist must be built");
  const tempDataDir = mkdtempSync(join(tmpdir(), "vr-r6-paths-"));
  let backendProc;
  let backendLog = "";
  let staticServer;
  let browser;
  try {
    const backendPort = await freePort();
    const frontendPort = await freePort();
    const backend = `http://127.0.0.1:${backendPort}`;
    frontend = `http://127.0.0.1:${frontendPort}`;
    const py = pythonConfig();
    const env = {
      ...process.env,
      VR_DATA_DIR: tempDataDir,
      VR_REPORTS_DIR: tempDataDir,
      VIBE_RESEARCH_TRADE_LEDGER_DB: join(tempDataDir, "trade_ledger.sqlite3"),
      VIBE_RESEARCH_REVIEW_DB: join(tempDataDir, "review_history.db"),
      VIBE_RESEARCH_EVIDENCE_THESIS_DB: join(tempDataDir, "evidence_thesis.db"),
      VIBE_RESEARCH_CAMPAIGN_DB: join(tempDataDir, "campaigns.sqlite3"),
      VIBE_RESEARCH_FROZEN_DECISION_DB: join(tempDataDir, "frozen_decisions.sqlite3"),
      PYTHONUNBUFFERED: "1",
      VR_ALLOW_ORIGINS: frontend,
      PYTHONPATH: [harnessDir, backendDir, process.env.PYTHONPATH].filter(Boolean).join(path.delimiter),
    };
    backendProc = spawn(py.cmd, [...py.args, "decision_challenge_backend_harness:app", "--host", "127.0.0.1", "--port", String(backendPort)], { cwd: backendDir, env, stdio: ["ignore", "pipe", "pipe"] });
    backendProc.stdout.on("data", (c) => { backendLog += c.toString(); });
    backendProc.stderr.on("data", (c) => { backendLog += c.toString(); });
    await waitHttp(`${backend}/api/health`);
    await jsonRequest(backend, "/api/position/bootstrap-commit", "POST", {
      ledger_start_at: "2026-08-01",
      opening_cash: 100000,
      positions: [{ code: "600519", name: "贵州茅台", shares: 100, cost_basis: 150000 }],
    }, 200);
    staticServer = await startStaticServer(frontendDist, frontendPort);
    const launchOptions = { headless: true };
    const executablePath = chromiumPath();
    if (executablePath) launchOptions.executablePath = executablePath;
    try {
      browser = await chromium.launch(launchOptions);
    } catch {
      browser = await chromium.launch({ headless: true, channel: "chrome" });
    }
    const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
    const appErrors = [];
    page.on("pageerror", (error) => appErrors.push(error.message));
    page.on("console", (message) => { if (message.type() === "error") console.log("[browser console] " + message.text()); });
    await page.route("https://fonts.googleapis.com/**", (route) => route.fulfill({ contentType: "text/css", body: "" }));
    const businessWrites = [];
    let historyFailure = false;
    page.on("request", (request) => { if (new URL(request.url()).pathname.startsWith("/api/") && !["GET", "HEAD", "OPTIONS"].includes(request.method())) businessWrites.push(request.url()); });
    await page.route("**/api/**", async (route) => {
      const request = route.request();
      const url = new URL(request.url());
      if (historyFailure && request.method() === "GET" && url.pathname.includes("/decision-proposal/committed/")) {
        await route.fulfill({ status: 503, contentType: "application/json", body: JSON.stringify({ detail: "synthetic history read outage" }) });
        return;
      }
      try {
        const response = await proxyRequest(`${backend}${url.pathname}${url.search}`, request.method(), request.headers(), ["GET", "HEAD"].includes(request.method()) ? undefined : request.postDataBuffer());
        await route.fulfill({ status: response.status, headers: response.headers, body: response.body });
      } catch (error) {
        await route.fulfill({ status: 599, contentType: "application/json", body: JSON.stringify({ detail: "proxy failed" }) });
      }
    });

    // ============ 路径二：PRE-ENTRY 决定可见但未交易 ============
    const campaignA = await createFrozenCampaignFixture(backend, "Path2 Formal Thesis");
    record("INFO", "fixture", `Campaign A=${campaignA.campaign.campaign_id}（PRE-ENTRY，fixture 准备）`);
    const decisionA = await commitDecisionViaUi(page, campaignA.campaign.campaign_id);
    const decisionB = await commitDecisionViaUi(page, campaignA.campaign.campaign_id, "第二份历史判断：保持等待");
    assert.notEqual(decisionA, decisionB);
    const writeMarker = businessWrites.length;

    await page.goto(`${frontend}/decision-inbox`, { waitUntil: "domcontentloaded", timeout: 60000 });
    await page.getByRole("heading", { name: "决策待办" }).waitFor({ timeout: 30000 });
    const panel = page.getByTestId(`campaign-committed-decisions-${campaignA.campaign.campaign_id}`);
    await panel.waitFor({ timeout: 30000 });
    const panelText = await panel.innerText();
    assert.ok(panelText.includes(decisionA), "panel must show the committed decision id");
    assert.match(panelText, /本面板仅展示已提交决定/);
    record("INFO", "路径二", "Inbox「正在建立的 Campaign」卡出现已提交决定面板（含决定 id 与不推断交易事实的说明）");
    await screenshot(page, "path2-inbox-committed-panel.png");

    const statusAfterCommit = await jsonRequest(backend, `/api/campaigns/${campaignA.campaign.campaign_id}`);
    assert.equal(statusAfterCommit.status, "PRE-ENTRY", "commit must not activate the campaign");
    const derived = await jsonRequest(backend, "/api/position/derived");
    record("INFO", "路径二", `Campaign 状态仍=${statusAfterCommit.status}；持仓未变（canonical ledger 不受决定影响）`);
    for (const [decisionId, note] of [[decisionA, "第一份历史判断"], [decisionB, "第二份历史判断：保持等待"]]) {
      await panel.locator("li").filter({ hasText: decisionId }).getByRole("link").click();
      await page.getByTestId("committed-decision-snapshot").getByText(note, { exact: false }).waitFor();
      assert.equal(new URL(page.url()).searchParams.get("decision_id"), decisionId);
      assert.match(await page.getByTestId("committed-decision-snapshot").innerText(), new RegExp(decisionId));
      assert.equal(await page.getByRole("button", { name: "Preview Proposal" }).count(), 0);
      await page.reload({ waitUntil: "domcontentloaded" });
      await page.getByTestId("committed-decision-snapshot").getByText(note, { exact: false }).waitFor();
      await screenshot(page, `history-${decisionId === decisionA ? "first" : "second"}.png`);
      await page.getByRole("link", { name: "返回 Decision Inbox", exact: true }).click();
      await panel.waitFor();
    }
    await page.goto(`${frontend}/campaigns/${campaignA.campaign.campaign_id}/decision-proposal?decision_id=invalid`);
    await page.getByRole("alert").getByText(/历史决定读取失败/).waitFor();
    assert.equal(await page.getByTestId("committed-decision-snapshot").count(), 0);
    historyFailure = true;
    await page.goto(`${frontend}/campaigns/${campaignA.campaign.campaign_id}/decision-proposal?decision_id=${decisionB}`, { waitUntil: "domcontentloaded" });
    await page.getByRole("alert").getByText(/历史决定读取失败/).waitFor();
    assert.equal(await page.getByTestId("committed-decision-snapshot").count(), 0);
    await screenshot(page, "history-read-failure.png");
    historyFailure = false;
    await page.getByRole("button", { name: "重新读取此决定" }).click();
    await page.getByTestId("committed-decision-snapshot").getByText("第二份历史判断：保持等待", { exact: false }).waitFor();
    assert.equal(businessWrites.length, writeMarker, "history open/reload/back/error must be read-only");
    assert.equal((await jsonRequest(backend, `/api/campaigns/${campaignA.campaign.campaign_id}`)).status, "PRE-ENTRY");
    console.log("[R5/R6 path2 PASS] two UI commits; exact-ID history + reload/back + invalid ID; zero business writes; PRE-ENTRY unchanged");
    assert.deepEqual(appErrors, [], "no browser runtime exceptions");
    assert.equal(await page.locator("vite-error-overlay").count(), 0);
    console.log("[browser identity] " + JSON.stringify({ url: page.url(), title: await page.title(), viewport: page.viewportSize() }));
  } catch (error) {
    if (backendProc && !backendProc.killed) console.error(backendLog || "backend log unavailable");
    throw error;
  } finally {
    if (browser) await browser.close();
    if (staticServer) await new Promise((resolve) => staticServer.close(resolve));
    if (backendProc && !backendProc.killed) {
      if (process.platform === "win32") {
        spawnSync("taskkill", ["/PID", String(backendProc.pid), "/T", "/F"], { stdio: "ignore", windowsHide: true });
      } else {
        backendProc.kill();
      }
      await new Promise((resolve) => backendProc.once("close", resolve));
    }
    try { rmSync(tempDataDir, { recursive: true, force: true }); } catch (cleanupError) {
      console.error(`[r6] temp dir cleanup skipped: ${cleanupError.code ?? cleanupError}`);
    }
  }
}


run().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
