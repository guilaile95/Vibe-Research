# Goal v2 follow-up evidence, 2026-09-07

Implementation self-verification for independent Gate. No final ACCEPT is asserted.
All browser fixtures and trades are synthetic and isolated in temporary VR_DATA_DIRs.
No real portfolio, account, research or secrets are included.

## Exact code coordinates

Stable and direct PR base: feature/research-system-v01 @ 7485848e74aca9d0c11b9c8a1a93b6e8c1a37da8.

| PR | Code head | Target / base |
|---|---|---|
| 278 | f3dc7bc252ac9b36d401bff1e6d7c5230f47008f | stable above |
| 279 | 821694f9d9b3d8cd9180a1f430579bbfd6581ee1 | stable above |
| 280 | fc882b8bb33544a8c7ef8cc1c52f5a427aecf7a8 | feat/research-brief-v01 @ f3dc7bc252ac9b36d401bff1e6d7c5230f47008f |
| 281 | 7a9bb67d66752b92e711e41459e717248751fb48 | stable above |
| 282 | 067f2caa5efd53fc7bd7679c683db40ffca340f3 | feat/research-brief-v01 @ f3dc7bc252ac9b36d401bff1e6d7c5230f47008f |
| 283 | 41102313332ae556be9294b6da764980a68f24e2 | stable above |

The evidence-only commit containing this archive does not change these code versions.
Integration/goal-v2-check @ 4d057acc7f09d7d7777da510d2da652c5f925456 passed all three browser runs in this archive, frontend build, and the combined 23 backend tests. This includes the final synchronous confirmation fix 067f2ca. An ancestry check then found the old integration omitted unchanged #279. It was merged without conflict, yielding 68eaaa01e20d402870a2d9c3911fed1defac7100; frontend build and all 9 sector-market-context tests passed there. #279 changes only sector coverage/provenance types, rendering and its backend calculation. No unrelated browser repeat was needed. Final evidence-only merge coordinates are in the PR body.

## Checks and reproducible commands

Use the existing project dependencies. PYTHON must point to the project environment with backend dependencies; locally it was E:/AI Projects/Vibe-Research/backend/.venv/Scripts/python.exe. No new test framework is required.

- Backend cwd: `python -m pytest tests/test_formal_thesis_delta.py tests/test_research_continuity.py tests/test_decision_committed_list.py tests/test_signal_effect_study.py -q` — 23 passed (17 + 2 + 4). The combined result was terminal-captured; individual #281 output is included.
- Backend cwd after merging #279: `python -m pytest tests/test_sector_market_context.py -q` — 9 passed, integration-sector-tests.log.
- Repository cwd: `node --experimental-strip-types --test frontend/tests/research-brief.test.ts frontend/tests/decision-context-hydration.test.ts` — 15 passed at #282 final code.
- Frontend cwd: `npm run build` — passed, integration-build.log. Existing chart chunk size warning retained.
- Frontend cwd, set PYTHON and E2E_SCREENSHOT_DIR to extracted pr282 directory: `npm run test:e2e:decision-commit` — passed, pr282/integration-browser.log. The same existing script also passed with DCR1_READBACK_VARIANT=malformed. Original ccedcfc ADDED wait retained.
- Repository cwd, set PYTHON, E2E_REPO_ROOT to the integrated checkout, E2E_SCREENSHOT_DIR to extracted pr283 directory: `node --import ./frontend/tests/e2e/runtime-env.mjs <extracted>/pr283/history.browser.mjs` — passed, pr283/integration-browser.log.
- Repository cwd, set PYTHON and E2E_REPO_ROOT: `node --import ./frontend/tests/e2e/runtime-env.mjs <extracted>/r6/paths.browser.mjs` — passed, r6/integration-browser.log. r6/goal_v2_harness.py must stay beside the script.
- Backend cwd, set PYTHONPATH to backend: `python <extracted>/pr281/verify_cli.py` — synthetic CSV import -> actual CLI -> JSON/CSV assertions passed. Reproduction writes only beside that script. The archived CLI log records the original invocation.
- `git diff --check` passed on affected branches and integrated checkout.

## R6 endpoints and screenshots

1. Frozen Thesis -> UI-created evidence -> actual stale-version 409 -> reload clears acknowledgment -> reconfirm -> one successful delta POST followed by injected GET 503 -> disabled submit and GET-only recovery; persistent delta count increases exactly once. ADDED -> new explicit WAIT decision through Preview/confirmation/Freeze. Original frozen snapshot and old decision unchanged. See pr282/delta-written-readback-unavailable.png, delta-readback-recovered.png, post-freeze-delta-brief.png and integration-browser.log. Initial count 1 -> final count 2, GET retry makes no POST.
2. Two content-distinct real synthetic decisions committed through UI. Each Inbox detail link reads its exact ID and historical snapshot, including after refresh and return. Unknown ID/503 shows honest error; read-only retry restores that same ID. No extra business writes or activation. See pr283/history-first.png, history-second.png, history-read-failure.png, path2-inbox-committed-panel.png and integration-browser.log.
3. Empty synthetic account + confirmed synthetic cash profile. Complete valuation/decision/Challenge UI -> committed BUY SMALL -> /trades UI buy 100 shares at 100 -> reopen row details -> explicit attribution -> ALLOCATED while Campaign remains PRE_ENTRY -> explicit activation -> ACTIVE. Real backend policy and writers validate each transition. See r6/path3-attributed-not-activated.png, path3-explicitly-activated.png and the exact decision/trade/attribution IDs in integration-browser.log.
4. Same campaign/decision/attribution -> UI new evidence -> explicit opposing DISPROVEN delta -> terminal banner. Original frozen snapshot, old committed decision and existing attribution are equal before/after (read-time projection as_of is excluded). Further append rejected 409. See r6/path4-terminal-banner.png and integration-browser.log.

Browser: actual Chromium pages at 1440x900, title/URL recorded. No runtime page exceptions or Vite overlay. Expected HTTP errors are deliberate 409/503/invalid-ID422 and optional challenge404. External Google font CSS is disabled in isolated runs. #282 uses explicit unavailable normalized network inputs; paths 3/4 fix normalized synthetic market capability observations only. Dependency resolution, hard risk, candidate decision, challenge, commit, trade, attribution and activation remain real code. No seedActiveCampaign, SQL activation or direct key write-service substitute is used. These prove wiring and state transitions, not live market capability or investment validity.

## #281 output meaning

Worst ranking uses return_pct for all EVALUATED events. Missing benchmark observations remain in the ledger and are excluded from excess statistics. Real CSV flags/counts are asserted via DictReader; failure-before.txt is the red mixed-benchmark regression. study.json/csv use signal_effect_study.v0.3, with signal definition unchanged. Requested dates, actual sample/benchmark ranges and dataset coverage are distinct. RESEARCH_ONLY; HISTORICAL_VALIDITY=NOT_PROVEN.

## CI and boundaries

Current CI is linked from each PR body; do not treat an old run as a newer head's result. #282 initial run 34079711109 failed the acknowledgment invalidation assertion, exposing a real passive-effect race; 067f2ca replaced it with synchronous input identity/clearing. Launcher workflow path filter is not matched by these changes: NOT_TRIGGERED_PATH_FILTER / N/A. The ordinary CI Python Windows lock check is a different job.

All PRs remain OPEN / DRAFT / NOT_MERGED. Stable unchanged. No Ready, Merge, deployment, cleanup, new phase or live-user data writes. R9 real historical verification and Owner real usage remain NOT_DONE. Unknown POST receipts remain UNKNOWN rather than automatically re-posting. No cross-session/global idempotency claim. Actual token usage source unavailable: UNKNOWN. Stop after authorized fixes, checks and evidence; independent Gate decides acceptance.
